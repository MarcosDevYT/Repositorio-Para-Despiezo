import { auth } from "@/auth";
import { SellProducts } from "@/components/layout/vendedor/SellProducts";
import { verifySeller } from "@/lib/utils";
import { redirect } from "next/navigation";

export default async function SellPage() {
  const session = await auth();

  if (!session?.user) redirect("/login");

  const isVerify = verifySeller(session);

  if (!isVerify) {
    redirect("/vendedor/negocio");
  }

  return <SellProducts />;
}
